/**
 * Estrutura de dados de brinquedos categorizados por idade e sexo
 * Design Philosophy: Playful Whimsy
 * - Inclusão: Brinquedos não-genéricos, adequados para todas as crianças
 * - Diversidade: Opções variadas que estimulam criatividade, aprendizado e movimento
 */

export interface Gift {
  id: string;
  name: string;
  description: string;
  icon: string;
  category: "creative" | "educational" | "sports" | "music" | "reading" | "outdoor" | "building" | "games";
}

export interface AgeGroup {
  min: number;
  max: number;
  label: string;
}

// Faixas etárias
export const ageGroups: AgeGroup[] = [
  { min: 2, max: 4, label: "2-4 anos" },
  { min: 5, max: 7, label: "5-7 anos" },
  { min: 8, max: 10, label: "8-10 anos" },
  { min: 11, max: 14, label: "11-14 anos" },
];

// Gêneros
export const genders = [
  { value: "masculine", label: "Masculino" },
  { value: "feminine", label: "Feminino" },
];

// Brinquedos para 2-4 anos
const gifts2to4: Record<string, Gift[]> = {
  neutral: [
    {
      id: "blocks-soft",
      name: "Blocos de Espuma Coloridos",
      description: "Blocos macios e seguros para construção e desenvolvimento motor",
      icon: "🧱",
      category: "building",
    },
    {
      id: "ball-sensory",
      name: "Bola Sensorial",
      description: "Bola com texturas diferentes para estimular tátil",
      icon: "🎾",
      category: "sports",
    },
    {
      id: "puzzle-simple",
      name: "Quebra-cabeça Simples",
      description: "Peças grandes e coloridas para coordenação motora",
      icon: "🧩",
      category: "educational",
    },
    {
      id: "xylophone",
      name: "Xilofone Infantil",
      description: "Instrumento musical para explorar sons e ritmos",
      icon: "🎵",
      category: "music",
    },
    {
      id: "toy-animals",
      name: "Animais de Brinquedo",
      description: "Figuras de animais para brincadeira imaginativa",
      icon: "🦁",
      category: "games",
    },
    {
      id: "stacking-rings",
      name: "Anéis para Empilhar",
      description: "Anéis coloridos para desenvolvimento motor e cores",
      icon: "🎯",
      category: "educational",
    },
    {
      id: "picture-book",
      name: "Livro de Figuras",
      description: "Livro com imagens grandes e cores vibrantes",
      icon: "📚",
      category: "reading",
    },
    {
      id: "push-toy",
      name: "Brinquedo para Empurrar",
      description: "Brinquedo que faz sons ao ser empurrado",
      icon: "🚂",
      category: "games",
    },
  ],
  masculine: [
    {
      id: "toy-truck",
      name: "Caminhão de Brinquedo",
      description: "Caminhão resistente para brincadeiras ao ar livre",
      icon: "🚚",
      category: "games",
    },
    {
      id: "tool-set",
      name: "Kit de Ferramentas Infantil",
      description: "Ferramentas de plástico seguro para construção",
      icon: "🔨",
      category: "building",
    },
    {
      id: "dinosaur-set",
      name: "Dinossauros de Brinquedo",
      description: "Figuras de dinossauros para imaginação e aprendizado",
      icon: "🦕",
      category: "games",
    },
    {
      id: "ball-foam",
      name: "Bola de Espuma",
      description: "Bola macia para arremessar e chutar com segurança",
      icon: "⚽",
      category: "sports",
    },
  ],
  feminine: [
    {
      id: "doll-soft",
      name: "Boneca de Pano",
      description: "Boneca macia e segura para brincadeira imaginativa",
      icon: "🧸",
      category: "games",
    },
    {
      id: "play-kitchen",
      name: "Cozinha de Brinquedo",
      description: "Cozinha com utensílios para brincadeira de faz-de-conta",
      icon: "🍳",
      category: "games",
    },
    {
      id: "tea-set",
      name: "Jogo de Chá Infantil",
      description: "Conjunto de chá para brincadeira de hospedagem",
      icon: "🫖",
      category: "games",
    },
    {
      id: "flower-puzzle",
      name: "Quebra-cabeça de Flores",
      description: "Peças em forma de flores para coordenação motora",
      icon: "🌸",
      category: "educational",
    },
  ],
};

// Brinquedos para 5-7 anos
const gifts5to7: Record<string, Gift[]> = {
  neutral: [
    {
      id: "lego-classic",
      name: "LEGO Classic",
      description: "Blocos de construção para criar estruturas criativas",
      icon: "🧱",
      category: "building",
    },
    {
      id: "board-game",
      name: "Jogo de Tabuleiro",
      description: "Jogo educativo para desenvolvimento de estratégia",
      icon: "🎲",
      category: "games",
    },
    {
      id: "art-supplies",
      name: "Kit de Artes e Ofícios",
      description: "Lápis, marcadores, papel para criatividade",
      icon: "🎨",
      category: "creative",
    },
    {
      id: "book-adventure",
      name: "Livro de Aventura",
      description: "Livro ilustrado com histórias envolventes",
      icon: "📖",
      category: "reading",
    },
    {
      id: "bicycle",
      name: "Bicicleta Infantil",
      description: "Bicicleta com rodinhas para aprender a pedalar",
      icon: "🚲",
      category: "sports",
    },
    {
      id: "skateboard",
      name: "Skate Infantil",
      description: "Skate pequeno e seguro para iniciantes",
      icon: "🛹",
      category: "sports",
    },
    {
      id: "roller-skates",
      name: "Patins Infantis",
      description: "Patins com proteção para diversão ao ar livre",
      icon: "⛸️",
      category: "sports",
    },
    {
      id: "kite",
      name: "Pipa",
      description: "Pipa colorida para brincadeira ao ar livre",
      icon: "🪁",
      category: "outdoor",
    },
    {
      id: "telescope",
      name: "Telescópio Infantil",
      description: "Telescópio simples para explorar o céu",
      icon: "🔭",
      category: "educational",
    },
    {
      id: "microscope",
      name: "Microscópio Infantil",
      description: "Microscópio para explorar o mundo microscópico",
      icon: "🔬",
      category: "educational",
    },
  ],
  masculine: [
    {
      id: "remote-car",
      name: "Carro de Controle Remoto",
      description: "Carro RC para brincadeira dinâmica",
      icon: "🚗",
      category: "games",
    },
    {
      id: "drone",
      name: "Drone Infantil",
      description: "Drone seguro e fácil de controlar",
      icon: "🛸",
      category: "games",
    },
    {
      id: "action-figures",
      name: "Figuras de Ação",
      description: "Personagens de super-heróis ou filmes populares",
      icon: "🦸",
      category: "games",
    },
    {
      id: "soccer-ball",
      name: "Bola de Futebol",
      description: "Bola de futebol de qualidade para jogar",
      icon: "⚽",
      category: "sports",
    },
    {
      id: "basketball",
      name: "Bola de Basquete",
      description: "Bola de basquete com cesta portátil",
      icon: "🏀",
      category: "sports",
    },
  ],
  feminine: [
    {
      id: "doll-fashion",
      name: "Boneca Fashion",
      description: "Boneca com roupas e acessórios variados",
      icon: "👗",
      category: "games",
    },
    {
      id: "jewelry-kit",
      name: "Kit de Joias DIY",
      description: "Contas e fios para criar joias personalizadas",
      icon: "💎",
      category: "creative",
    },
    {
      id: "dollhouse",
      name: "Casa de Bonecas",
      description: "Casa com móveis e personagens para brincadeira",
      icon: "🏠",
      category: "games",
    },
    {
      id: "craft-kit",
      name: "Kit de Artesanato",
      description: "Materiais para criar pulseiras, colares e mais",
      icon: "🧶",
      category: "creative",
    },
    {
      id: "roller-skates-pink",
      name: "Patins Coloridos",
      description: "Patins com design colorido e proteção",
      icon: "⛸️",
      category: "sports",
    },
  ],
};

// Brinquedos para 8-10 anos
const gifts8to10: Record<string, Gift[]> = {
  neutral: [
    {
      id: "lego-advanced",
      name: "LEGO Technic",
      description: "LEGO avançado com mecanismos complexos",
      icon: "🧱",
      category: "building",
    },
    {
      id: "science-kit",
      name: "Kit de Ciências",
      description: "Experimentos científicos educativos",
      icon: "🧪",
      category: "educational",
    },
    {
      id: "book-series",
      name: "Série de Livros",
      description: "Série popular para leitores em desenvolvimento",
      icon: "📚",
      category: "reading",
    },
    {
      id: "guitar",
      name: "Violão Infantil",
      description: "Violão pequeno para aprender música",
      icon: "🎸",
      category: "music",
    },
    {
      id: "keyboard",
      name: "Teclado Eletrônico",
      description: "Teclado com sons e ritmos variados",
      icon: "🎹",
      category: "music",
    },
    {
      id: "skateboard-pro",
      name: "Skate Profissional",
      description: "Skate de qualidade para praticantes",
      icon: "🛹",
      category: "sports",
    },
    {
      id: "roller-blades",
      name: "Rollerblades",
      description: "Patins em linha com proteção completa",
      icon: "⛸️",
      category: "sports",
    },
    {
      id: "camping-kit",
      name: "Kit de Camping",
      description: "Barraca e equipamentos para acampamento",
      icon: "⛺",
      category: "outdoor",
    },
    {
      id: "binoculars",
      name: "Binóculos",
      description: "Binóculos para observação da natureza",
      icon: "🔭",
      category: "educational",
    },
    {
      id: "coding-robot",
      name: "Robô de Programação",
      description: "Robô programável para aprender lógica",
      icon: "🤖",
      category: "educational",
    },
  ],
  masculine: [
    {
      id: "rc-helicopter",
      name: "Helicóptero RC",
      description: "Helicóptero de controle remoto avançado",
      icon: "🚁",
      category: "games",
    },
    {
      id: "gaming-console",
      name: "Console de Videogame",
      description: "Console portátil para jogos educativos",
      icon: "🎮",
      category: "games",
    },
    {
      id: "model-kit",
      name: "Kit de Modelo",
      description: "Modelo de avião, carro ou nave para montar",
      icon: "✈️",
      category: "building",
    },
    {
      id: "baseball-glove",
      name: "Luva de Beisebol",
      description: "Luva e bola para jogar beisebol",
      icon: "⚾",
      category: "sports",
    },
    {
      id: "tennis-racket",
      name: "Raquete de Tênis",
      description: "Raquete infantil para jogar tênis",
      icon: "🎾",
      category: "sports",
    },
  ],
  feminine: [
    {
      id: "jewelry-maker",
      name: "Máquina de Fazer Joias",
      description: "Máquina para criar joias personalizadas",
      icon: "💍",
      category: "creative",
    },
    {
      id: "sewing-kit",
      name: "Kit de Costura",
      description: "Agulhas, linhas e tecidos para costurar",
      icon: "🧵",
      category: "creative",
    },
    {
      id: "art-easel",
      name: "Cavalete de Arte",
      description: "Cavalete duplo com tela e tintas",
      icon: "🎨",
      category: "creative",
    },
    {
      id: "photography-camera",
      name: "Câmera Infantil",
      description: "Câmera digital simples para fotografia",
      icon: "📷",
      category: "educational",
    },
    {
      id: "scooter",
      name: "Scooter Infantil",
      description: "Scooter com 3 rodas para estabilidade",
      icon: "🛴",
      category: "sports",
    },
  ],
};

// Brinquedos para 11-14 anos
const gifts11to14: Record<string, Gift[]> = {
  neutral: [
    {
      id: "lego-architecture",
      name: "LEGO Architecture",
      description: "Modelos de arquitetura famosa para montar",
      icon: "🏛️",
      category: "building",
    },
    {
      id: "advanced-science-kit",
      name: "Kit Avançado de Ciências",
      description: "Experimentos complexos de física e química",
      icon: "⚛️",
      category: "educational",
    },
    {
      id: "book-classic",
      name: "Livro Clássico",
      description: "Clássicos da literatura adaptados para jovens",
      icon: "📖",
      category: "reading",
    },
    {
      id: "digital-piano",
      name: "Piano Digital",
      description: "Piano com 88 teclas para aprender música",
      icon: "🎹",
      category: "music",
    },
    {
      id: "drums",
      name: "Bateria Eletrônica",
      description: "Bateria com sons profissionais",
      icon: "🥁",
      category: "music",
    },
    {
      id: "skateboard-extreme",
      name: "Skate de Competição",
      description: "Skate profissional para truques avançados",
      icon: "🛹",
      category: "sports",
    },
    {
      id: "mountain-bike",
      name: "Bicicleta Mountain Bike",
      description: "Bicicleta para trilhas e terrenos variados",
      icon: "🚵",
      category: "sports",
    },
    {
      id: "tent-camping",
      name: "Barraca de Camping",
      description: "Barraca de qualidade para acampamentos",
      icon: "⛺",
      category: "outdoor",
    },
    {
      id: "dslr-camera",
      name: "Câmera DSLR Infantil",
      description: "Câmera digital para fotografia amadora",
      icon: "📸",
      category: "educational",
    },
    {
      id: "drone-advanced",
      name: "Drone Avançado",
      description: "Drone com câmera e controle remoto",
      icon: "🛸",
      category: "games",
    },
  ],
  masculine: [
    {
      id: "gaming-pc",
      name: "PC Gamer Portátil",
      description: "Computador para jogos educativos",
      icon: "💻",
      category: "games",
    },
    {
      id: "rc-car-advanced",
      name: "Carro RC Profissional",
      description: "Carro de controle remoto de alta velocidade",
      icon: "🏎️",
      category: "games",
    },
    {
      id: "engineering-kit",
      name: "Kit de Engenharia",
      description: "Componentes para construir máquinas",
      icon: "⚙️",
      category: "building",
    },
    {
      id: "basketball-hoop",
      name: "Cesta de Basquete",
      description: "Cesta regulamentação para treinar",
      icon: "🏀",
      category: "sports",
    },
    {
      id: "football-helmet",
      name: "Equipamento de Futebol Americano",
      description: "Capacete e proteção para futebol americano",
      icon: "🏈",
      category: "sports",
    },
  ],
  feminine: [
    {
      id: "jewelry-professional",
      name: "Kit Profissional de Joias",
      description: "Ferramentas profissionais para fazer joias",
      icon: "💎",
      category: "creative",
    },
    {
      id: "sewing-machine",
      name: "Máquina de Costura",
      description: "Máquina de costura para iniciantes",
      icon: "🪡",
      category: "creative",
    },
    {
      id: "pottery-wheel",
      name: "Roda de Cerâmica",
      description: "Roda de cerâmica para criar peças",
      icon: "🏺",
      category: "creative",
    },
    {
      id: "instant-camera",
      name: "Câmera Instantânea",
      description: "Câmera que imprime fotos na hora",
      icon: "📹",
      category: "educational",
    },
    {
      id: "roller-skates-advanced",
      name: "Patins de Competição",
      description: "Patins profissionais para competição",
      icon: "⛸️",
      category: "sports",
    },
  ],
};

// Mapa de todos os presentes por faixa etária
const giftsByAge: Record<string, Record<string, Gift[]>> = {
  "2-4": gifts2to4,
  "5-7": gifts5to7,
  "8-10": gifts8to10,
  "11-14": gifts11to14,
};

/**
 * Obtém um presente aleatório baseado na idade e sexo
 * @param age Idade da criança (2-14)
 * @param gender Gênero (neutral, masculine, feminine)
 * @returns Um presente aleatório da categoria apropriada
 */
export function getRandomGift(age: number, gender: string): Gift | null {
  // Encontra a faixa etária apropriada
  const ageGroup = ageGroups.find((group) => age >= group.min && age <= group.max);

  if (!ageGroup) {
    return null;
  }

  const ageKey = `${ageGroup.min}-${ageGroup.max}`;
  const gifts = giftsByAge[ageKey]?.[gender] || giftsByAge[ageKey]?.["masculine"] || [];

  if (gifts.length === 0) {
    return null;
  }

  // Retorna um presente aleatório
  const randomIndex = Math.floor(Math.random() * gifts.length);
  return gifts[randomIndex];
}

/**
 * Obtém todos os presentes para uma faixa etária e gênero específicos
 * @param age Idade da criança
 * @param gender Gênero
 * @returns Array de presentes disponíveis
 */
export function getGiftsForAgeAndGender(age: number, gender: string): Gift[] {
  const ageGroup = ageGroups.find((group) => age >= group.min && age <= group.max);

  if (!ageGroup) {
    return [];
  }

  const ageKey = `${ageGroup.min}-${ageGroup.max}`;
  return giftsByAge[ageKey]?.[gender] || giftsByAge[ageKey]?.["masculine"] || [];
}
