/**
 * Home Page - Presentes da Sorte
 * Design Philosophy: Playful Whimsy
 * 
 * Features:
 * - Seleção de idade (2-14 anos)
 * - Seleção de gênero (neutro, masculino, feminino)
 * - Sorteio aleatório de presentes
 * - Animações lúdicas e feedback visual
 * - Interface acessível e intuitiva
 */

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Gift, ageGroups, genders, getRandomGift } from "@/lib/gifts";
import { Sparkles } from "lucide-react";

export default function Home() {
  const [selectedAge, setSelectedAge] = useState<number | null>(null);
  const [selectedGender, setSelectedGender] = useState<string | null>(null);
  const [suggestedGift, setSuggestedGift] = useState<Gift | null>(null);
  const [isSpinning, setIsSpinning] = useState(false);
  const [showResult, setShowResult] = useState(false);

  const handleSuggestGift = () => {
    if (!selectedAge || !selectedGender) {
      alert("Por favor, selecione a idade e o gênero!");
      return;
    }

    setIsSpinning(true);
    setShowResult(false);

    // Simula o tempo de sorteio com animação
    setTimeout(() => {
      const gift = getRandomGift(selectedAge, selectedGender);
      setSuggestedGift(gift);
      setIsSpinning(false);
      setShowResult(true);
    }, 2000);
  };

  const handleReset = () => {
    setSelectedAge(null);
    setSelectedGender(null);
    setSuggestedGift(null);
    setShowResult(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-white via-blue-50 to-purple-50 flex flex-col">
      {/* Header */}
      <header className="bg-gradient-to-r from-coral to-purple-400 text-white py-8 px-4 text-center shadow-lg">
        <div className="container mx-auto">
          <h1 className="text-5xl font-bold mb-2 flex items-center justify-center gap-3">
            <span className="text-5xl">🎁</span>
            Presentes da Sorte
          </h1>
          <p className="text-xl font-light opacity-90">
            Descubra o presente perfeito para cada criança!
          </p>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 container mx-auto py-12 px-4">
        <div className="grid lg:grid-cols-2 gap-8 items-start">
          {/* Selection Panel */}
          <div className="space-y-8">
            {/* Age Selection */}
            <Card className="p-8 border-2 border-yellow-300 shadow-xl hover:shadow-2xl transition-shadow">
              <h2 className="text-3xl font-bold text-coral mb-6 flex items-center gap-2">
                <span className="text-4xl">👧</span>
                Selecione a Idade
              </h2>
              <div className="grid grid-cols-2 gap-4">
                {ageGroups.map((group) => (
                  <button
                    key={`${group.min}-${group.max}`}
                    onClick={() => setSelectedAge(group.min)}
                    className={`p-4 rounded-xl font-bold text-lg transition-all duration-300 transform hover:scale-105 border-2 ${
                      selectedAge === group.min
                        ? "bg-gradient-to-r from-coral to-red-500 text-white shadow-xl scale-105 border-red-600"
                        : "bg-light-gray text-dark-text hover:bg-yellow-100 border-yellow-300"
                    }`}
                  >
                    {group.label}
                  </button>
                ))}
              </div>
            </Card>

            {/* Gender Selection */}
            <Card className="p-8 border-2 border-green-300 shadow-xl hover:shadow-2xl transition-shadow">
              <h2 className="text-3xl font-bold text-green-600 mb-6 flex items-center gap-2">
                <span className="text-4xl">👨‍👩‍👧‍👦</span>
                Selecione o Gênero
              </h2>
              <div className="space-y-3">
                {genders.map((gender) => (
                  <button
                    key={gender.value}
                    onClick={() => setSelectedGender(gender.value)}
                    className={`w-full p-4 rounded-xl font-bold text-lg transition-all duration-300 transform hover:scale-105 text-left border-2 ${
                      selectedGender === gender.value
                        ? "bg-gradient-to-r from-green-500 to-emerald-600 text-white shadow-xl scale-105 border-emerald-700"
                        : "bg-light-gray text-dark-text hover:bg-green-100 border-green-300"
                    }`}
                  >
                    {gender.label}
                  </button>
                ))}
              </div>
            </Card>

            {/* Action Buttons */}
            <div className="flex gap-4">
              <Button
                onClick={handleSuggestGift}
                disabled={isSpinning}
                className="flex-1 bg-gradient-to-r from-coral to-purple-500 hover:from-red-500 hover:to-purple-600 text-white font-bold py-6 text-lg rounded-xl shadow-lg hover:shadow-xl transform hover:scale-105 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Sparkles className="mr-2 w-5 h-5" />
                {isSpinning ? "Sorteando..." : "Sortear Presente! 🎉"}
              </Button>
              {showResult && (
                <Button
                  onClick={handleReset}
                  variant="outline"
                  className="flex-1 border-2 border-coral text-coral font-bold py-6 text-lg rounded-xl hover:bg-coral hover:text-white transition-all"
                >
                  Novo Sorteio
                </Button>
              )}
            </div>
          </div>

          {/* Result Panel */}
          <div className="flex items-center justify-center">
            {showResult && suggestedGift ? (
              <Card className="w-full p-8 bg-gradient-to-br from-yellow-100 to-purple-100 border-4 border-yellow-300 shadow-2xl animate-bounce">
                <div className="text-center space-y-6">
                  <div className="text-8xl animate-spin" style={{ animationDuration: "2s" }}>
                    {suggestedGift.icon}
                  </div>
                  <h3 className="text-4xl font-bold text-coral">{suggestedGift.name}</h3>
                  <p className="text-lg text-dark-text leading-relaxed">
                    {suggestedGift.description}
                  </p>
                  <div className="pt-4 border-t-2 border-yellow-300">
                    <p className="text-sm font-semibold text-purple-600 uppercase tracking-wide">
                      Categoria: {suggestedGift.category}
                    </p>
                  </div>
                </div>
              </Card>
            ) : (
              <Card className="w-full p-12 bg-gradient-to-br from-blue-50 to-green-50 border-2 border-dashed border-coral shadow-lg">
                <div className="text-center space-y-4">
                  <div className="text-7xl">🎪</div>
                  <h3 className="text-2xl font-bold text-dark-text">
                    Pronto para a Sorte?
                  </h3>
                  <p className="text-lg text-muted-foreground">
                    Selecione a idade e o gênero, depois clique em "Sortear Presente!" para descobrir uma sugestão especial.
                  </p>
                </div>
              </Card>
            )}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-100 text-black py-8 px-4 text-center border-t-2 border-gray-200">
        <div className="container mx-auto">
          <p className="text-lg font-light mb-2 text-black">
            Um projeto social de doação de presentes para crianças do orfanato
          </p>
          <p className="text-sm text-black opacity-80">
            Desenvolvido com ❤️ pelos alunos do curso técnico de DS
          </p>
        </div>
      </footer>
    </div>
  );
}
